## IMPORTS GO HERE if required

## END OF IMPORTS 


#### YOUR CODE FOR netIncome GOES HERE ####


#### End OF MARKER


