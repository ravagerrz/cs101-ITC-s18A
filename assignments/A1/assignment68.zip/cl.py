Bad programmers worry about the code. Good programmers worry about data structures and their relationships.
